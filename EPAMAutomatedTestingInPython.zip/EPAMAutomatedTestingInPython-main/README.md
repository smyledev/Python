# Solutions of tasks
