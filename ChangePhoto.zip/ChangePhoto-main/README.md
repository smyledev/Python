# Change color of photo and create photo collage

## Photo before changing 

![Photo1](image.jpg)

## Photo after changing color 

![Photo2](result1.png)

## Photo after making collage 

![Photo2](result2.png)
